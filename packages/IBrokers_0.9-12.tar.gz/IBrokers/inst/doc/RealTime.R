### R code from vignette source 'RealTime.Rnw'

###################################################
### code chunk number 1: reqCurrentTime (eval = FALSE)
###################################################
## writeBin(c("49","1"), con)


###################################################
### code chunk number 2: twsCALLBACK
###################################################
require(IBrokers)
deparse(twsCALLBACK)[30:47]


