### R code from vignette source 'IBrokersREFCARD.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(continue="  ")


###################################################
### code chunk number 2: orders (eval = FALSE)
###################################################
## placeOrder(twsconn=tws,
##            Contract=twsSTK("AAPL"), 
##            Order=twsOrder(reqIds(tws),
##                           "BUY", 
##                           10, 
##                           "MKT"))


