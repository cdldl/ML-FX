package org.extratrees.data;

public interface Row {
	public double get(int col);
}
