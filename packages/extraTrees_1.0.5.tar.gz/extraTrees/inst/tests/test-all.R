library(testthat)
library(extraTrees)

test_check("extraTrees")
